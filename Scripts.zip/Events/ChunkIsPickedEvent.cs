﻿using UnityEngine.Events;

public class ChunkIsPickedEvent : UnityEvent
{
    
}
