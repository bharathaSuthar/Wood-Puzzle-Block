﻿using UnityEngine.Events;

public class ChunkIsReleasedEvent : UnityEvent
{
    
}
