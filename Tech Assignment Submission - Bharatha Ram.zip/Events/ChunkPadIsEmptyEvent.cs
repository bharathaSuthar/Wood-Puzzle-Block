﻿using UnityEngine.Events;

public class ChunkPadIsEmptyEvent : UnityEvent
{
    
}
