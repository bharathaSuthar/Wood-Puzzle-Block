﻿using UnityEngine.Events;

public class UpdateScoreEvent : UnityEvent<int>
{
    
}
