﻿using UnityEngine.Events;

public class GameOverEvent : UnityEvent
{
    
}
